#include "BME280Sensor.h"

// Konstrukt�r: Tar imot navn og initialiserer private felt
BME280Sensor::BME280Sensor(String nName) 
    : name(nName) 
{
    // Objektet bme initialiseres automatisk her.
}

// Starter sensoren og I2C-kommunikasjon
bool BME280Sensor::begin() {
    Serial.println("Starter BME280 Sensor...");
    
    // Wire.begin() er n�dvendig for I2C og kalles vanligvis i setup(), 
    // men vi kaller den her for � sikre at modulen er selvstendig
    Wire.begin(); 
    
    // Standard I2C-adresse for BME280 er 0x76 (eller 0x77). 
    // Vi bruker standardadressen her.
    unsigned status = bme.begin(); 

    if (!status) {
        Serial.println("FEIL: Finner ikke BME280! Sjekk tilkobling/adresse.");
        return false;
    }
    
    Serial.println("BME280 initialisert OK.");
    return true;
}

// Leser alle verdier og returnerer en struktur
BMEData BME280Sensor::readData() {
    BMEData data;
    
    // Adafruit BME280-biblioteket returnerer:
    // - Temperatur i Celsius
    // - Fuktighet i %
    // - Trykk i Pascal (Pa), s� vi deler med 100 for hPa
    
    data.temperature = bme.readTempC();
    data.humidity = bme.readFloatHumidity();
    data.pressure = bme.readFloatPressure() / 100.0F; // Konverterer Pa til hPa

    return data;
}

// Returnerer sensorens navn
String BME280Sensor::getName() {
    return name;
}