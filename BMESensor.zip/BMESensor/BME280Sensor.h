#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <SparkFunBME280.h>
// Struktur for � holde alle m�linger samlet
struct BMEData {
    float temperature; // Temperatur i Celsius
    float humidity;    // Relativ fuktighet i prosent
    float pressure;    // Trykk i hPa (Hektopascal)
};

class BME280Sensor {
private:
    // Det private Adafruit BME280-objektet
    BME280 bme; 
    String name;
    
public:
    // Konstrukt�r: Tar et navn
    BME280Sensor(String name);

    // Initialiserer sensoren og sjekker status. Returnerer true ved suksess.
    bool begin();

    // Leser alle sensorm�linger og returnerer BMEData-strukturen
    BMEData readData();
    
    // Hjelpemetode
    String getName();
};