#pragma once
#include <Arduino.h>

class LDRSensor {
private:
    int analogPin;
    String name;
    
    // Kalibrering: Disse b�r settes i begin() eller via en metode
    int darkValue = 150;  // R�verdi for "helt m�rkt"
    int brightValue = 850; // R�verdi for "helt lyst"
    
    // Konstanter for Moving Average (filtrering)
    static const int WINDOW_SIZE = 10; 
    int readings[WINDOW_SIZE];
    int readIndex = 0;
    
public:
    // Konstrukt�r
    LDRSensor(String name, int pin);

    // Initialiserer sensor/filter
    void begin();
    
    // Setter de dynamiske kalibreringspunktene
    void setCalibration(int dark, int bright);

    // Leser r�verdien direkte
    int readRawValue();

    // Leser filtrert verdi ved hjelp av Moving Average
    int readFilteredValue();

    // Returnerer lysniv�et som prosent (0% = m�rkt, 100% = lyst)
    int getLightPercentage();

    // Returnerer boolsk status basert p� en terskel (f.eks. for � sl� p� lys)
    bool isDark(int thresholdPercent);
    
    String getName();
};