    #include "LDRSensor.h"

    #define LDR_PIN A1      // Koble LDR til Analog Pin A1
    #define LED_PIN 13      // Lys som skal sl�s p� (f.eks. innebygd LED)
    #define DARK_THRESHOLD 25 // 25% lys eller lavere regnes som m�rkt

    // Egendefinerte kalibreringspunkter
    // VIKTIG: Sett disse basert p� dine egne m�linger i m�rke/lys
    #define MY_DARK_RAW 850
    #define MY_BRIGHT_RAW 150

    LDRSensor lysSensor("Ute-Lys", LDR_PIN);

    void setup() {
        Serial.begin(9600);
        lysSensor.begin();
    
        // Sett de kalibrerte punktene for din LDR
        lysSensor.setCalibration(MY_DARK_RAW, MY_BRIGHT_RAW); 
    
        pinMode(LED_PIN, OUTPUT);
    }

    void loop() {
    
        // Filtrert verdi i % (0=m�rkt, 100=lyst)
        int lightPercentage = lysSensor.getLightPercentage();
    
        Serial.print("Lysniv�: ");
        Serial.print(lightPercentage);
        Serial.print("% | ");
    
        // Bruker den dynamiske terskelmetoden
        if (lysSensor.isDark(DARK_THRESHOLD)) {
            Serial.println("STATUS: M�RKT (Sl�r P� lys)");
            digitalWrite(LED_PIN, HIGH);
        } else {
            Serial.println("STATUS: LYST nok (Sl�r AV lys)");
            digitalWrite(LED_PIN, LOW);
        }
    
        delay(500);
    }