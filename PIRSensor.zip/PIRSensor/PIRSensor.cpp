#include "PIRSensor.h"

// Konstrukt�r
PIRSensor::PIRSensor(String nName, int pin) 
    : name(nName), detectionPin(pin) 
{
    // Konstrukt�ren lagrer pinnen og navnet
}

/**
 * Initialiserer pinnen. 
 * Bruker standard INPUT. (Mange PIR-moduler har internt kretsl�p som hindrer floating.)
 * Alternativt kan INPUT_PULLUP brukes hvis man opplever st�y.
 */
void PIRSensor::begin() {
    pinMode(detectionPin, INPUT);
    
    // Hvis du opplever st�y, kan du bruke:
    // pinMode(detectionPin, INPUT_PULLUP);
    
    Serial.print(name);
    Serial.println(" PIR-detektor initialisert.");
}
bool PIRSensor::checkAndLogMotion() {
    int pirState = digitalRead(detectionPin);
    
    if (pirState == HIGH) {
        //Oppdaterer lastMotion til N�
        this->lastMotion = millis(); 
        return true; 
    }
    return false;
}
bool PIRSensor::checkMotion(){
    int state = digitalRead(detectionPin);

    if (state == HIGH){
        return true;
    }
    return false;
}

/**
 * Kalkulerer hvor mange millisekunder det har g�tt siden siste bevegelse.
 * Viser hvor lenge en "tidtaker" har v�rt aktiv/inaktiv.
 */
unsigned long PIRSensor::timeSinceLastMotion() {
    // Dette h�ndterer "rollover" (at millis() g�r tilbake til 0) korrekt.
    // N�tid (millis()) minus lagret tid (lastMotion).
    return millis() - this->lastMotion;
}

// Returnerer sensorens navn
String PIRSensor::getName() {
    return name;
}